#!/bin/sh
set -e
echo "=== Installation complète Interface + Icônes + Wi-Fi SM-T561 ==="

# 1. Paquets légers compatibles noyau 3.10.17
sudo apk add --force-broken-world --allow-untrusted \
  tint2 pcmanfm lxterminal faenza-icon-theme matchbox-keyboard \
  jgmenu feh dillo xsetroot wpa_supplicant dropbear

# 2. Correctif icônes PNG (évite le crash SVG ENOSYS)
sudo sed -i "/svg/,\$d" /usr/lib/gdk-pixbuf-2.0/2.10.0/loaders.cache 2>/dev/null || true
sudo gtk-update-icon-cache -f /usr/share/icons/Faenza 2>/dev/null || true

# 3. Interface, menus, fond d écran et batterie
mkdir -p ~/.config ~/Pictures
cp -r config/* ~/.config/
cp -r Pictures/* ~/Pictures/ 2>/dev/null || true
sudo mkdir -p /usr/local/bin /usr/share/applications
sudo cp bin/bat-status.sh /usr/local/bin/ 2>/dev/null || true
sudo chmod +x /usr/local/bin/bat-status.sh 2>/dev/null || true
sudo cp apps/*.desktop /usr/share/applications/ 2>/dev/null || true

# 4. Configuration Wi-Fi autonome (sans NetworkManager)
sudo mkdir -p /etc/NetworkManager/conf.d /etc/wpa_supplicant /etc/local.d
printf "[keyfile]\nunmanaged-devices=interface-name:wlan0\n" | sudo tee /etc/NetworkManager/conf.d/unmanaged-wifi.conf >/dev/null
if [ ! -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
    sudo cp wifi/wpa_supplicant.conf.exemple /etc/wpa_supplicant/wpa_supplicant.conf
fi

cat << "WIFIEOF" | sudo tee /etc/local.d/wifi-direct.start >/dev/null
#!/bin/sh
rfkill unblock all 2>/dev/null
killall -9 wpa_supplicant udhcpc 2>/dev/null
ip link set wlan0 down
sleep 1
ip link set wlan0 up
wpa_supplicant -B -D nl80211,wext -i wlan0 -c /etc/wpa_supplicant/wpa_supplicant.conf
sleep 4
udhcpc -i wlan0 -b -q
GW=$(ip route show dev wlan0 | awk "/default/ {print \$3}" | head -n 1)
[ -z "$GW" ] && GW=$(ip -4 addr show wlan0 | awk "/inet / {print \$2}" | cut -d. -f1-3).1
ip route del default 2>/dev/null || true
ip route add default via $GW dev wlan0 2>/dev/null || true
WIFIEOF
sudo chmod +x /etc/local.d/wifi-direct.start
sudo rc-update add local default
sudo rc-update add dropbear default

# 5. Verrouillage DNS rapide
sudo chattr -i /etc/resolv.conf 2>/dev/null || true
printf "nameserver 1.1.1.1\nnameserver 8.8.8.8\n" | sudo tee /etc/resolv.conf >/dev/null
sudo chattr +i /etc/resolv.conf 2>/dev/null || true

echo "=== Terminé ! Pensez à mettre votre nom de box et mot de passe dans /etc/wpa_supplicant/wpa_supplicant.conf ==="
sudo service lightdm restart
